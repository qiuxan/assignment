<?php
	//Standard page setup
	
	$KERNEL_LOCATION = '../';    
	require($KERNEL_LOCATION.'includes.php');
    
	$pageTitle       = 'Page Title Here';
	$rootPath        = '../../';
	$pageContents    = 'updatecontent.php';

	//Include the master page
	require($rootPath.'master_page.php');

	
?>


